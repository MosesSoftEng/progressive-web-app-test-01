var cars = [
    {
        model: "X5",
        brand: "BMW",
        image: "https://i.picsum.photos/id/237/300/200.jpg?hmac=WSdbBEXvCVSqNN1HnCzm7ohp6DhAJfl9t3TcqBNDn_Q"
    },
    {
        model: "Compass",
        brand: "Jeep",
        image: "https://i.picsum.photos/id/227/300/200.jpg?hmac=sDKlw0KWcPXSlMFA8nGNBPwT-twHwiVXKTYWxFKF7Y8"
    }
];
